document
.getElementById("loginForm")
.addEventListener(
"submit",
loginUser
);

async function loginUser(e){

e.preventDefault();

const email =
document
.getElementById("email")
.value
.trim();

const password =
document
.getElementById("password")
.value;

const loginBtn =
document.querySelector(
"#loginForm button"
);

loginBtn.disabled = true;
loginBtn.innerText =
"Logging In...";

const {
data,
error
}
=
await supabaseClient.auth
.signInWithPassword({

email,
password

});

if(error){

alert(
error.message
);

loginBtn.disabled = false;
loginBtn.innerText =
"Login";

return;

}

const userId =
data.user.id;

const {
data:userData,
error:userError
}
=
await supabaseClient
.from("users")
.select("*")
.eq("id",userId)
.single();

if(userError){

alert(
"User Profile Not Found"
);

return;
}

if(
userData.is_active === false
){

alert(
"Account Disabled"
);

await supabaseClient.auth
.signOut();

return;
}

localStorage.setItem(
"skc_user",
JSON.stringify(userData)
);

if(
userData.role === "owner"
){

window.location.href =
"pages/owner-dashboard.html";

}
else if(
userData.role === "manager"
){

window.location.href =
"pages/manager-dashboard.html";

}
else{

window.location.href =
"pages/supervisor-dashboard.html";

}

}